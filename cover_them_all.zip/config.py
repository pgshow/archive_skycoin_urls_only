import dblite3

DB_OBJ = dblite3.DB()

# setting
Threading_Num = 1
Domain = "blackhatworld.com"
Is_Import_From_File = True
Import_File = './url_files/blackhatworld.txt'

# Domain = "skycoin.com"
# Is_Import_From_File = False
